library(testthat)
library(ASSAMC)

test_check("ASSAMC")
